*******************************************************
*  Name      :  Mohan Kancherla        
*  Student ID:  109421260               
*  Class     :  CSC 2312           
*  Due Date  :  Apr 08, 2019
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

The program "main" will read the data from CSV file for the player and assign the grid.
It will randomly assign the ship positions for computer player. After that it will ask
the position to fire torpedo's for player and randomly assign position for computer player.

After firing of torpedos, whoever grid is completely sunk, the other player wins

*******************************************************
*  Source files
*******************************************************

Name:  main.cpp

   Main program. This program will read the data from the CSV file and will assign the ships
   to the player 1 . It will randomly assign the ships to computer player by using srand function.
   After firing of torpedos and complete destruction of one of the player grid's, it will display
   who won the battleship game.
   
Name: PlayerGrid.cpp

   This will provide the definition of all the member functions in the PlayerGrid.h header file
   and will provide the whether the shot is miss or hit on ship

Name: PlayerShip.cpp

    This program will provide the defintion of all member functions present in the PlayerShip.cpp
    header file.
   
*******************************************************
*  Status of program
*******************************************************

   The program runs successfully.  
   
   The program was developed and tested on Visual Studios g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

